import { Injectable } from '@angular/core';
import { InMemoryDbService } from 'angular-in-memory-web-api';
import { User } from '../models/user';

@Injectable({
  providedIn: 'root'
})
export class InMemoryDataService implements InMemoryDbService {
  createDb() {
    const users = new Array<User> (
      {id: 1, firstName: 'Arman', lastName: 'Tsarukyan'},
      {id: 2, firstName: 'Ilia', lastName: 'Topuria'},
      {id: 3, firstName: 'Islam', lastName: 'Makhachev'},
      {id: 4, firstName: 'Alexandre', lastName: 'Topuria'},
      {id: 5, firstName: 'Khabib', lastName: 'Nurmagomedov'},
      {id: 6, firstName: 'Charles', lastName: 'Oliveira'},
      {id: 7, firstName: 'Kamaru', lastName: 'Usman'},
      {id: 8, firstName: 'Shavkhat', lastName: 'Rakhmonov'},
      {id: 9, firstName: 'Khamzat', lastName: 'Chimaev'},
      {id: 10, firstName: 'Usman', lastName: 'Nurmagomedov'},
    );

    return { users };
  }

  constructor() { }
}
